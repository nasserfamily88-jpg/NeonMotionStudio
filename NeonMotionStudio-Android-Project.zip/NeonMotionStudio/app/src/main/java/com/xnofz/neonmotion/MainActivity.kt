package com.xnofz.neonmotion

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 7, 17)
    private val panel = Color.rgb(22, 17, 34)
    private val purple = Color.rgb(179, 77, 255)
    private val white = Color.rgb(245, 240, 255)
    private val muted = Color.rgb(157, 145, 179)
    private lateinit var timeline: LinearLayout
    private lateinit var layerList: LinearLayout
    private var frame = 0
    private var keyframeCount = 0
    private var selectedTool = "Layers"
    private val layers = mutableListOf("Text • XNOFZ", "Glow effect", "Main footage")
    private val effects = mutableListOf("Neon Glow", "RGB Split", "Motion Blur")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        render()
    }

    private fun shape(color: Int, radius: Float = 18f, stroke: Int = 0): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color); cornerRadius = radius
            if (stroke != 0) setStroke(2, stroke)
        }
    }

    private fun text(s: String, size: Float, color: Int = white, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = s; textSize = size; setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
        }

    private fun baseColumn(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(16, 12, 16, 12)
        setBackgroundColor(bg)
    }

    private fun addGap(parent: LinearLayout, h: Int = 10) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, h))
    }

    private fun button(label: String, active: Boolean = false, action: () -> Unit): TextView =
        TextView(this).apply {
            text = label; textSize = 13f; gravity = Gravity.CENTER
            setTextColor(if (active) Color.WHITE else muted)
            setPadding(12, 10, 12, 10)
            background = shape(if (active) purple else panel, 24f, if (active) purple else Color.rgb(53, 40, 72))
            setOnClickListener { action() }
        }

    private fun row(parent: LinearLayout, children: List<View>, weights: List<Float>? = null) {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        children.forEachIndexed { i, v ->
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, weights?.get(i) ?: 1f)
            if (i > 0) lp.leftMargin = 6
            r.addView(v, lp)
        }
        parent.addView(r)
    }

    private fun card(parent: LinearLayout, child: View, padding: Int = 12) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(padding, padding, padding, padding)
            background = shape(panel, 18f, Color.rgb(48, 36, 66))
        }
        box.addView(child)
        parent.addView(box, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 10 })
    }

    private fun render() {
        val root = baseColumn()
        val scroller = ScrollView(this)
        scroller.addView(root)
        setContentView(scroller)

        row(root, listOf(text("NEON", 20f, purple, true), text("MOTION STUDIO  •  BETA", 11f, muted, true), button("⚙", action = { toast("Settings — قريباً") })), listOf(1f, 2f, .5f))
        addGap(root, 14)
        text("مشروع جديد", 22f, white, true).also { root.addView(it) }
        text("مونتاج • موشن جرافيك • إيدتات أنمي", 12f, muted).also { root.addView(it) }
        addGap(root, 14)

        val preview = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(12, 30, 12, 30)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(35, 10, 60), Color.rgb(10, 8, 20), Color.rgb(46, 8, 70))).apply { cornerRadius = 22f; setStroke(2, purple) }
        }
        preview.addView(text("✦", 24f, purple, true).apply { gravity = Gravity.CENTER })
        preview.addView(text("XNOFZ", 34f, white, true).apply { gravity = Gravity.CENTER; letterSpacing = .16f; setShadowLayer(22f, 0f, 0f, purple) })
        preview.addView(text("NEON PREVIEW  •  FRAME ${frame}", 10f, muted, true).apply { gravity = Gravity.CENTER })
        card(root, preview, 10)

        row(root, listOf(button("▶ Play", action = { frame += 1; render() }),
            button("◆ Add Keyframe", action = { keyframeCount++; toast("تمت إضافة Keyframe رقم $keyframeCount") }),
            button("＋ Import", action = { toast("استيراد الوسائط — قيد التطوير") })), listOf(1f, 1.5f, 1f))
        addGap(root, 12)

        row(root, listOf(
            button("Layers", selectedTool == "Layers") { selectedTool = "Layers"; render() },
            button("Effects", selectedTool == "Effects") { selectedTool = "Effects"; render() },
            button("Text", selectedTool == "Text") { selectedTool = "Text"; render() },
            button("Audio", selectedTool == "Audio") { selectedTool = "Audio"; render() }
        ))
        addGap(root, 10)

        when (selectedTool) {
            "Layers" -> {
                text("LAYERS  •  ${layers.size}", 13f, purple, true).also { root.addView(it) }
                addGap(root, 6)
                layers.forEachIndexed { i, layer ->
                    row(root, listOf(text(if (i == 0) "▣  $layer" else "▤  $layer", 13f),
                        button("↑") { if (i > 0) { val x = layers.removeAt(i); layers.add(i-1, x); render() } },
                        button("×") { layers.removeAt(i); render() }), listOf(3f, .7f, .7f))
                    addGap(root, 5)
                }
                button("＋ Add layer") { layers.add("New layer ${layers.size + 1}"); render() }.also { root.addView(it) }
            }
            "Effects" -> {
                text("EFFECTS  •  NEON TOOLKIT", 13f, purple, true).also { root.addView(it) }
                addGap(root, 6)
                effects.forEach { e -> row(root, listOf(text("✦  $e", 13f), button("Toggle") { toast("$e — تم تبديل الحالة تجريبياً") }), listOf(2f, 1f)); addGap(root, 6) }
                button("＋ Browse effects") { toast("مكتبة التأثيرات — قيد التطوير") }.also { root.addView(it) }
            }
            "Text" -> {
                text("TEXT DESIGN", 13f, purple, true).also { root.addView(it) }; addGap(root, 6)
                val field = EditText(this).apply { setText("XNOFZ"); setTextColor(white); textSize = 20f; setHintTextColor(muted); background = shape(Color.rgb(13,10,23), 12f, purple); setPadding(12, 10, 12, 10) }
                root.addView(field)
                addGap(root, 6)
                button("Apply text") { toast("النص: ${field.text} — معاينة أولية") }.also { root.addView(it) }
            }
            "Audio" -> {
                text("AUDIO TRACK", 13f, purple, true).also { root.addView(it) }; addGap(root, 6)
                text("♫  لا يوجد ملف صوتي مضاف", 13f, muted).also { root.addView(it) }
                button("＋ Add audio") { toast("استيراد الصوت — قيد التطوير") }.also { root.addView(it) }
            }
        }

        addGap(root, 12)
        card(root, LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(text("TIMELINE", 13f, purple, true))
            addView(text("00:${(frame / 30).toString().padStart(2,'0')}:${(frame % 30).toString().padStart(2,'0')}     •     ${keyframeCount} keyframes", 11f, muted))
            addGap(this, 8)
            addView(SeekBar(this@MainActivity).apply {
                max = 300; progress = frame.coerceIn(0,300)
                progressTintList = android.content.res.ColorStateList.valueOf(purple)
                thumbTintList = android.content.res.ColorStateList.valueOf(white)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { if (fromUser) { frame = p } }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) { render() }
                })
            })
            addView(text("TEXT  ━━━━━━━━━━━━━━━ ◆ ━━━━━", 11f, white))
            addView(text("FOOTAGE ━━━━━━━━━━━━━━━━━━━", 11f, muted))
            addView(text("AUDIO   ━━━━━━━━━━━━━━━━", 11f, purple))
        }, 12)

        button("⇧  Export video", true) { toast("التصدير الفعلي للفيديو غير مفعّل في نسخة المعاينة") }.also { root.addView(it, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT)) }
        addGap(root, 8)
        text("Prototype v0.1 • بعض الوظائف تجريبية وليست معالجة فيديو فعلية بعد", 10f, muted).also { root.addView(it) }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
