# Neon Motion Studio — Android prototype

A native Android Studio starter project for a dark purple/black mobile motion-editing UI.

## Current prototype
- Timeline scrubber and frame counter
- Add-keyframe counter (UI prototype; not yet tied to real animated properties)
- Layer list with add, remove and reorder
- Effects panel (toggle actions are placeholders)
- Text field preview workflow
- Audio import placeholder
- Export button placeholder

## Build APK
1. Open this folder in Android Studio (Giraffe or newer; Android Gradle Plugin 8.7.3).
2. Allow Gradle sync and install Android SDK Platform 35 if prompted.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Android Studio will show the APK location, normally `app/build/outputs/apk/debug/app-debug.apk`.

## Important
This is a functional UI prototype, not yet a full video editor. Real media import, audio/video decoding, keyframe interpolation, GPU effects, and MP4 export still need implementation and testing. No prebuilt APK is included.
